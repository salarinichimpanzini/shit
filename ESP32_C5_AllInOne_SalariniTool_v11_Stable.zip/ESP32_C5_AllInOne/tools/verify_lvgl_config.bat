@echo off
setlocal
set "LVGL=C:\Arduino\libraries\lvgl"
echo Checking %LVGL% ...
if not exist "%LVGL%\lvgl.h" (
  echo ERROR: %LVGL%\lvgl.h not found.
  exit /b 1
)
if not exist "%LVGL%\src\lvgl.h" (
  echo ERROR: %LVGL%\src\lvgl.h not found.
  exit /b 1
)
if not exist "%LVGL%\lv_conf.h" (
  echo ERROR: %LVGL%\lv_conf.h not found.
  echo Run tools\install_libraries.bat first.
  exit /b 1
)
findstr /C:"#define LV_COLOR_SCREEN_TRANSP 1" "%LVGL%\lv_conf.h" >nul
if errorlevel 1 (
  echo ERROR: wrong LV_COLOR_SCREEN_TRANSP setting in lv_conf.h.
  echo Expected: #define LV_COLOR_SCREEN_TRANSP 1
  exit /b 1
)
echo LVGL installation OK.
exit /b 0
