@echo off
setlocal
cd /d "%~dp0.."
if exist tools\check_lvgl_api.bat call tools\check_lvgl_api.bat
if errorlevel 1 goto :fail
if not exist lv_conf.h goto :fail
if not exist libraries\lvgl\lvgl.h goto :fail
if not exist libraries\lvgl\src\lvgl.h goto :fail
if not exist libraries\SensorLib\library.properties goto :fail
echo PRE-FLIGHT: PASS
echo LVGL project headers and API arity checks passed.
exit /b 0
:fail
echo PRE-FLIGHT: FAIL
exit /b 1
