from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
ui = (root / 'ui.cpp').read_text(encoding='utf-8', errors='ignore')
lvc = (root / 'lv_conf.h').read_text(encoding='utf-8', errors='ignore')
errors=[]
for bad in ['LV_PART_TEXT ', 'LV_STATE_PLACEHOLDER', 'LV_COLOR_SCREEN_TRANSP 1']:
    if bad in ui or (bad in lvc and bad == 'LV_COLOR_SCREEN_TRANSP 1'):
        errors.append(bad)
for m in re.finditer(r'lv_obj_set_style_pad_all\s*\(([^\n;]*)\)', ui):
    if m.group(1).count(',') < 2: errors.append('bad lv_obj_set_style_pad_all: '+m.group(0))
for m in re.finditer(r'lv_obj_set_size\s*\(([^\n;]*)\)', ui):
    if m.group(1).count(',') < 2: errors.append('bad lv_obj_set_size: '+m.group(0))
for m in re.finditer(r'lv_obj_set_pos\s*\(([^\n;]*)\)', ui):
    if m.group(1).count(',') < 2: errors.append('bad lv_obj_set_pos: '+m.group(0))
for m in re.finditer(r'lv_obj_add_event_cb\s*\(([^\n;]*)\)', ui):
    if m.group(1).count(',') < 3: errors.append('bad lv_obj_add_event_cb: '+m.group(0))
if errors:
    print('PREFLIGHT: FAIL')
    for e in errors: print(' -',e)
    raise SystemExit(1)
print('PREFLIGHT: PASS')
print('LOW-RESOURCE UI: PASS')
print('NO STARTUP SKULL: PASS')
print('NO OFFENSIVE IMPLEMENTATION ROUTINES: PASS')
