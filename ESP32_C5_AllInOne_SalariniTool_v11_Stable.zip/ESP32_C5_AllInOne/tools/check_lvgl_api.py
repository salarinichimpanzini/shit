from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
CPP = [p for p in ROOT.rglob('*.cpp') if 'libraries' not in p.parts]
H = [p for p in ROOT.rglob('*.h') if 'libraries' not in p.parts]
FILES = [p for p in (CPP + H) if p.name not in {'check_lvgl_api.py'}]

checks = [
    (r'LV_PART_TEXT\b', 'LV_PART_TEXT is not a generic LVGL 8 part; use the widget-specific part.'),
    (r'LV_STATE_PLACEHOLDER\b', 'LV_STATE_PLACEHOLDER is not valid for the bundled LVGL 8.4 textarea API.'),
]

errors=[]
for path in FILES:
    text=path.read_text(encoding='utf-8', errors='ignore')
    for pat,msg in checks:
        if re.search(pat,text):
            errors.append(f'{path.relative_to(ROOT)}: {msg}')

# Basic arity guards for the APIs that repeatedly caused build failures.
for path in CPP:
    text=path.read_text(encoding='utf-8', errors='ignore')
    for name, msg in [
        ('lv_obj_set_size', 'must have obj,w,h'),
        ('lv_obj_set_pos', 'must have obj,x,y'),
        ('lv_obj_set_style_pad_all', 'must have obj,value,selector'),
    ]:
        for m in re.finditer(r'\b'+name+r'\s*\(', text):
            start=m.end(); depth=1; i=start; commas=0; in_str=None; esc=False
            while i < len(text) and depth:
                c=text[i]
                if in_str:
                    if esc: esc=False
                    elif c=='\\': esc=True
                    elif c==in_str: in_str=None
                else:
                    if c in "'\"": in_str=c
                    elif c=='(': depth += 1
                    elif c==')': depth -= 1
                    elif c==',' and depth==1: commas += 1
                i += 1
            if depth==0:
                if name in ('lv_obj_set_size','lv_obj_set_pos') and commas < 2:
                    errors.append(f'{path.relative_to(ROOT)}: {name} {msg}')
                elif name=='lv_obj_set_style_pad_all' and commas < 2:
                    errors.append(f'{path.relative_to(ROOT)}: {name} {msg}')

if errors:
    print('LVGL API CHECK: FAIL')
    for e in errors: print(' -',e)
    raise SystemExit(1)
print('LVGL API CHECK: PASS')
