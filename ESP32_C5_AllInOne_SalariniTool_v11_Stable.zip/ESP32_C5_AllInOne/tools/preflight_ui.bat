@echo off
py "%~dp0preflight_ui.py"
if errorlevel 1 pause
