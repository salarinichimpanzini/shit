#!/usr/bin/env python3
from pathlib import Path
import re, sys
root = Path(__file__).resolve().parents[1]
patterns = {
    "lv_obj_set_height": 2,
    "lv_obj_set_width": 2,
    "lv_obj_set_size": 3,
    "lv_obj_set_pos": 3,
    "lv_obj_set_x": 2,
    "lv_obj_set_y": 2,
    "lv_obj_set_style_pad_all": 3,
    "lv_obj_add_event_cb": 4,
    "lv_obj_align": 4,
}
# Conservative lexical scan: reports obvious literal bad calls like
# lv_obj_set_height(38) without trying to parse arbitrary C++ expressions.
bad=[]
for p in root.rglob('*.cpp'):
    for ln, line in enumerate(p.read_text(errors='ignore').splitlines(),1):
        for fn, expected in patterns.items():
            m=re.search(r'\b'+fn+r'\s*\((.*)\)\s*;', line)
            if not m: continue
            arg=m.group(1).strip()
            # count only top-level commas
            depth=0; n=1 if arg else 0
            for c in arg:
                if c=='(': depth+=1
                elif c==')': depth=max(0,depth-1)
                elif c==',' and depth==0: n+=1
            if n < expected:
                bad.append(f'{p.relative_to(root)}:{ln}: {fn} has {n} args; expected >= {expected}')
if bad:
    print('\n'.join(bad)); sys.exit(1)
print('LVGL setter API CHECK: PASS')
