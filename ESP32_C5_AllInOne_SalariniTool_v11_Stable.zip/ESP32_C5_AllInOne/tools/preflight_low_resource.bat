@echo off
python "%~dp0preflight_low_resource.py"
if errorlevel 1 pause
