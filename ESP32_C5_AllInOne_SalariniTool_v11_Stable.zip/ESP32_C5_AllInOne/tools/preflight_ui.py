from pathlib import Path
import re, sys
root = Path(__file__).resolve().parents[1]
ui = (root / 'ui.cpp').read_text(encoding='utf-8')
checks = {
    'LV_PART_TEXT': r'\bLV_PART_TEXT\b',
    'LV_STATE_PLACEHOLDER': r'\bLV_STATE_PLACEHOLDER\b',
    'one-arg set_height': r'lv_obj_set_height\(\s*[^,()]+\s*\)',
    'one-arg set_width': r'lv_obj_set_width\(\s*[^,()]+\s*\)',
    'one-arg set_pos': r'lv_obj_set_pos\(\s*[^,()]+\s*,\s*[^,()]+\s*\)',
    'one-arg pad_all': r'lv_obj_set_style_pad_all\(\s*[^,()]+\s*,\s*[^,()]+\s*\)',
}
failed = False
for name, pat in checks.items():
    if re.search(pat, ui):
        print('FAIL:', name)
        failed = True
print('UI PREFLIGHT:', 'FAIL' if failed else 'PASS')
if failed: sys.exit(1)
