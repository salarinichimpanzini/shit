@echo off
python "%~dp0check_lvgl_setter_calls.py"
if errorlevel 1 exit /b 1
pause
