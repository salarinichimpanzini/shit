@echo off
setlocal EnableExtensions

rem Repair LVGL for this project when Arduino is installed/used from C:\Arduino.
set "PROJECT_ROOT=%~dp0.."
for %%I in ("%PROJECT_ROOT%") do set "PROJECT_ROOT=%%~fI"
set "SRC=%PROJECT_ROOT%\libraries\lvgl"
set "DEST=C:\Arduino\libraries\lvgl"

if not exist "%SRC%\lvgl.h" (
  echo ERROR: No se encuentra el LVGL incluido en el proyecto:
  echo   "%SRC%\lvgl.h"
  exit /b 1
)

if not exist "C:\Arduino\libraries" mkdir "C:\Arduino\libraries"

if exist "%DEST%" (
  echo Haciendo copia de seguridad de la instalacion LVGL actual...
  if exist "C:\Arduino\libraries\lvgl_broken_backup" rmdir /s /q "C:\Arduino\libraries\lvgl_broken_backup"
  move /Y "%DEST%" "C:\Arduino\libraries\lvgl_broken_backup" >nul
)

mkdir "%DEST%" >nul 2>&1
xcopy "%SRC%\*" "%DEST%\" /E /I /H /Y >nul
if errorlevel 1 (
  echo ERROR: No se pudo copiar LVGL.
  exit /b 1
)

echo.
echo LVGL reparado correctamente en:
echo   "%DEST%"
echo.
echo Comprueba que exista:
echo   "%DEST%\lvgl.h"
echo   "%DEST%\src\lvgl.h"
echo.
echo Cierra y vuelve a abrir Arduino IDE antes de compilar.
pause
endlocal
