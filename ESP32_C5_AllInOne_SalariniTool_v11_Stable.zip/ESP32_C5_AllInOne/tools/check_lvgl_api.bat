@echo off
setlocal
cd /d "%~dp0.."
where py >nul 2>nul
if %errorlevel%==0 (py tools\check_lvgl_api.py) else (python tools\check_lvgl_api.py)
if errorlevel 1 pause
exit /b %errorlevel%
