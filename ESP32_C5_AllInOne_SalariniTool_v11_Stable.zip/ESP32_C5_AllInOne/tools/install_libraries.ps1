param(
    [string]$ArduinoRoot = ""
)

$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$source = Join-Path $projectRoot 'libraries'

if ([string]::IsNullOrWhiteSpace($ArduinoRoot)) {
    # This project was built/tested around the user's C:\Arduino layout,
    # but also support the normal Documents\Arduino layout.
    if (Test-Path 'C:\Arduino\libraries') {
        $ArduinoRoot = 'C:\Arduino'
    } else {
        $ArduinoRoot = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Arduino'
    }
}

$arduinoLibraries = Join-Path $ArduinoRoot 'libraries'
New-Item -ItemType Directory -Force -Path $arduinoLibraries | Out-Null

Get-ChildItem -Directory $source | ForEach-Object {
    $destination = Join-Path $arduinoLibraries $_.Name
    Write-Host "Installing $($_.Name) -> $destination"

    if (Test-Path $destination) {
        $backup = Join-Path $arduinoLibraries ("{0}_backup" -f $_.Name)
        if (Test-Path $backup) { Remove-Item -Recurse -Force $backup }
        Move-Item -Force $destination $backup
    }

    New-Item -ItemType Directory -Force -Path $destination | Out-Null
    Copy-Item -Recurse -Force (Join-Path $_.FullName '*') $destination
}

Write-Host ""
Write-Host "Libraries installed in: $arduinoLibraries"
Write-Host "Restart Arduino IDE if it was open."
Write-Host ""
Write-Host "The bundled LVGL includes its matching lv_conf.h so LV_COLOR_SCREEN_TRANSP is applied to the compiled library sources."
