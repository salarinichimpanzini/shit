# SALARINI TOOL — guía para añadir menús y funciones

Esta guía está escrita para una persona o para otra IA que vaya a ampliar el firmware sin convertirlo en un `.ino` gigante.

## 1. Regla principal de arquitectura

Mantén cada función independiente:

```text
ESP32_C5_AllInOne/
├── ESP32_C5_AllInOne.ino   # solo entrada Arduino
├── app.cpp/.h              # ciclo principal y coordinación
├── app_state.cpp/.h        # estado compartido de dispositivos
├── ui.cpp/.h               # páginas y eventos de la interfaz
├── soft_keyboard.cpp/.h     # teclado táctil reutilizable
├── display.cpp/.h           # ST7796 + LVGL
├── touch_ft6336.cpp/.h      # FT6336 -> LVGL
├── wifi_manager.cpp/.h      # WiFi
├── time_manager.cpp/.h      # RTC/NTP/NVS
├── sensor_*.cpp/.h          # sensores
├── power_pmu.cpp/.h         # batería/PMU
└── docs/                    # documentación de extensiones
```

No metas un driver completo en `ui.cpp`. La UI solo debería llamar al módulo y pintar el resultado.

## 2. Añadir una página nueva al menú

### Paso A — añade el identificador

En `ui.h`, añade una entrada al enum `Page`:

```cpp
enum Page : uint8_t {
    PAGE_HOME,
    // ...
    PAGE_MI_MODULO
};
```

### Paso B — declara el constructor visual

En la sección privada de `AppUi`:

```cpp
void buildMiModulo();
```

### Paso C — registra la página en `show()`

En `ui.cpp`:

```cpp
case PAGE_MI_MODULO:
    buildMiModulo();
    break;
```

### Paso D — crea la página

Ejemplo seguro y modular:

```cpp
void AppUi::buildMiModulo() {
    makeLabel(content_, "MI MODULO", 12, 8);

    lv_obj_t *p = makeSection(content_, "STATUS", 38, 105);
    makeLabel(p, "STATE", 11, 35);
    makeLabel(p, "READY", 120, 35);

    lv_obj_t *run = lv_btn_create(content_);
    lv_obj_set_size(run, 142, 40);
    lv_obj_set_pos(run, 10, 160);
    styleButton(run, CYAN);

    lv_obj_t *l = lv_label_create(run);
    lv_label_set_text(l, "RUN TEST");
    lv_obj_center(l);
    lv_obj_add_event_cb(run, miModuloEvent, LV_EVENT_CLICKED, nullptr);
}
```

Usa coordenadas con margen. Para esta pantalla de 320×480:

```text
x = 0..319
header = y 0..55
content = y 56..435
footer = y 436..479
```

Dentro de `content_`, deja normalmente:

```text
margen izquierdo = 10 px
ancho máximo      = 300 px
separación        = 8..12 px
```

Nunca pongas dos controles en el mismo rectángulo. Primero dibuja las cajas y después coloca sus textos.

## 3. Añadir un botón con acción

Declara una callback estática en `ui.h`:

```cpp
static void miModuloEvent(lv_event_t *e);
```

Implementa al final de `ui.cpp`:

```cpp
void AppUi::miModuloEvent(lv_event_t *) {
    // Llamar al módulo real aquí.
}
```

Si el botón solo navega a otra página, no necesitas una callback nueva. Puedes usar:

```cpp
lv_obj_add_event_cb(
    button,
    menuEvent,
    LV_EVENT_CLICKED,
    reinterpret_cast<void *>(static_cast<intptr_t>(PAGE_MI_MODULO))
);
```

## 4. Añadir una función de hardware

Crea un módulo separado:

```text
mi_sensor.cpp
mi_sensor.h
```

Ejemplo de interfaz:

```cpp
class MiSensor {
public:
    bool begin();
    bool update();
    float value() const;
    bool ready() const;
};

extern MiSensor miSensor;
```

Luego, en `app.cpp`, actualiza el módulo con su propia frecuencia. No bloquees el bucle durante segundos.

## 5. Añadir valores al estado global

Si una lectura debe verse desde varias páginas, agrégala a `AppState`:

```cpp
struct AppState {
    // ...
    float myValue = 0.0f;
    bool mySensorOk = false;
};
```

Actualízala en `app.cpp` y úsala desde `ui.cpp`.

## 6. Añadir un campo de texto

No uses directamente `lv_keyboard` si quieres mantener el teclado de SALARINI. Usa el teclado reutilizable:

```cpp
myInput_ = lv_textarea_create(content_);
lv_obj_set_size(myInput_, 300, 44);
lv_obj_set_pos(myInput_, 10, 110);
styleInput(myInput_);
lv_textarea_set_one_line(myInput_, true);
lv_textarea_set_placeholder_text(myInput_, "write here");

lv_obj_add_event_cb(
    myInput_,
    inputEvent,
    LV_EVENT_CLICKED,
    reinterpret_cast<void *>(static_cast<intptr_t>(1))
);
```

La callback `inputEvent()` abre `softKeyboard`.

Modos disponibles:

```cpp
SoftKeyboard::ALPHA
SoftKeyboard::NUMERIC
SoftKeyboard::SYMBOLS
```

El teclado tiene cambio de modo, mayúsculas/minúsculas, espacio, retroceso y confirmar.

## 7. Diseñar para que nunca se rocen controles

La pantalla es pequeña. Usa una cuadrícula mental:

```text
+------------------------------+
| HEADER 0..55                 |
+------------------------------+
|                              |
| CONTENT 56..435              |
|                              |
|  x=10                 x=310  |
|                              |
+------------------------------+
| FOOTER 436..479              |
+------------------------------+
```

Para botones grandes:

```text
ancho   = 142
alto    = 40..62
separación horizontal >= 14
separación vertical   >= 8
```

Dos columnas estándar:

```cpp
left  = 10;
right = 168;
width = 142;
```

No pongas un texto largo en un botón pequeño. Divide título y subtítulo y reserva como mínimo 20 px de altura para cada línea.

## 8. Scroll

Para una página larga:

```cpp
lv_obj_add_flag(content_, LV_OBJ_FLAG_SCROLLABLE);
lv_obj_set_scroll_dir(content_, LV_DIR_VER);
lv_obj_set_scrollbar_mode(content_, LV_SCROLLBAR_MODE_AUTO);
```

Para listas internas, crea otro contenedor con el mismo patrón.

No hagas que header y footer formen parte del contenedor desplazable.

## 9. Animaciones

Evita `lv_obj_set_style_transform_zoom()` en esta plataforma: puede requerir capas de transparencia y memoria adicional.

Para animar elementos de esta interfaz es preferible:

```cpp
lv_obj_set_x(obj, x);
lv_obj_set_y(obj, y);
lv_obj_set_size(obj, w, h);
lv_obj_set_style_bg_color(obj, color, 0);
```

La animación de arranque usa precisamente este enfoque: piezas opacas reposicionadas y redimensionadas, sin capas transparentes.

## 10. Funciones de red y seguridad

La base del proyecto es `passive-first` y orientada a equipos propios o autorizados. Buenos candidatos para nuevos módulos:

```text
WiFi survey / RSSI
Network profile
DNS resolver
I2C discovery
Sensor monitor
Storage diagnostics
BLE discovery
Local service diagnostics
HTTP diagnostics
OTA manager
Profile loader
Export/import settings
```

Las funciones que puedan interferir con redes ajenas, capturar credenciales o generar denegación de servicio no deben añadirse como comportamiento por defecto del firmware.

## 11. Patrón recomendado para una función futura

Una función nueva debería seguir este flujo:

```text
hardware/API
   ↓
module.cpp/.h
   ↓
app.cpp  → AppState
   ↓
ui.cpp  → página / botón / indicador
   ↓
soft_keyboard (solo si hace falta entrada)
```

Así una IA puede modificar un módulo sin romper el resto del proyecto.

## 12. Plantilla para pedir una ampliación a otra IA

Copia este bloque y sustituye los campos:

```text
PROYECTO: SALARINI TOOL / ESP32-C5 / LVGL 8.x

OBJETIVO:
Añade el módulo [NOMBRE].

ARCHIVOS QUE PUEDE MODIFICAR:
- [lista]

ARCHIVOS QUE NO DEBE ROMPER:
- display.cpp/.h
- touch_ft6336.cpp/.h
- app.cpp/.h
- app_state.cpp/.h

REQUISITOS UI:
- 320x480
- header fijo
- footer fijo
- margen 10 px
- dos columnas x=10 y x=168 cuando proceda
- separación >= 8 px
- ningún control puede solaparse
- usar estilo SALARINI oscuro
- no convertir la UI en una terminal de texto

ENTRADA:
Usar soft_keyboard cuando sea necesario.

SEGURIDAD:
Mantener funciones pasivas/locales/autorizadas.

ENTREGA:
1. código completo de los archivos modificados
2. lista exacta de archivos nuevos
3. explicación de dónde se registra el menú
4. comandos de compilación/prueba
5. indicar cualquier API que dependa de una versión concreta de Arduino-ESP32
```
