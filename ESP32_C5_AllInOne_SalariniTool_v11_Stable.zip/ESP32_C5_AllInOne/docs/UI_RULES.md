# SALARINI TOOL UI rules

1. `content_` is the only scrollable container.
2. Page rows are 40 px high with a 6 px vertical gap.
3. Long text must use a width and `LV_LABEL_LONG_CLIP` or wrap inside a dedicated text block.
4. Never use nested scroll containers.
5. Never place controls with hard-coded screen coordinates if a flex column can do it.
6. The header is fixed. All non-root pages have the `<` back button.
7. Wi-Fi scan rows select an AP; they do not ask for a password.
8. Wi-Fi connection has its own screen and its own password field/keyboard.
9. Exploit-labeled modules are UI/lab simulations only. Real Wi-Fi functionality is passive scanning, channel analysis and ordinary STA connection.
10. Keep animations short (about 90-200 ms) and avoid transforms, shadows and transparent layers.
