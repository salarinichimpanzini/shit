# Hardware map used by the supplied examples

## I2C

- SDA: GPIO27
- SCL: GPIO26
- Bus clock: 400 kHz
- Board I/O expander: `0x24`
- FT6336: `0x38`
- SHTC3: `0x70`
- AXP2101: `0x34`
- QMI8658: `0x6B` with `0x6A` fallback
- PCF85063: SensorLib default address

## ST7796 / SPI2

- SCLK: GPIO6
- MOSI: GPIO7
- MISO: GPIO2
- LCD CS: GPIO8
- LCD DC: GPIO5
- Resolution: 320x480
- SPI clock: 60 MHz

## SD/TF / SPI2

- SCLK: GPIO6
- MOSI: GPIO7
- MISO: GPIO2
- SD CS: GPIO9
- Mount point: `/sd_card`

