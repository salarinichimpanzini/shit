# Build / validation notes


A physical ESP32-C5 compile/flash was not performed in this environment because the Arduino ESP32 board package/toolchain is not installed here. Before flashing real hardware, use the supplied board package version and board selection documented in `README.md`, then resolve any board-package-specific compiler differences that only appear in a real build.

The source was intentionally kept modular so those fixes can be made in the affected driver without turning the sketch into one large `.ino`.
