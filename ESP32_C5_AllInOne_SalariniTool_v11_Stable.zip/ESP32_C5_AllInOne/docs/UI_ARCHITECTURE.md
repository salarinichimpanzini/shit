# SALARINI UI architecture

The UI uses one fixed header, one scrollable content area and one fixed footer. Each page uses LVGL Flex Column so cards and controls are stacked instead of being placed at arbitrary y coordinates.

## Rules

1. Put one logical control per row unless a row is explicitly a two-control container.
2. A card owns its labels and controls; do not position children using screen coordinates.
3. Use `makeNavCard`, `makeCard`, `makeButton` and `makeField` for new UI.
4. Keep at least 6 px between rows and 10 px horizontal page padding.
5. For text, use the width of the parent/card and `LV_LABEL_LONG_WRAP` for multi-line content.
6. Never create a second scrollable list inside `content_` for ordinary menus.
7. When adding a feature, give it a page enum, a `buildX()` method and a callback. Store long-lived hardware state in `AppState` or the module owning it.
8. Do not use `lv_obj_set_pos()` for normal page elements. It is reserved for fixed header/footer/keyboard/splash geometry.

## Wi-Fi safety boundary

The Wi-Fi pages provide scan inventory, channel analysis and defensive audits. The firmware does not implement deauthentication, jamming, credential capture or packet injection. New wireless modules should remain diagnostic/passive unless a future implementation has an explicitly authorized test mode with a clear scope.
