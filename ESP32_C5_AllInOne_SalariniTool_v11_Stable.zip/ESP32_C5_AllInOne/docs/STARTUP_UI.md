# Startup UI

The startup text/splash was removed in the low-resource revision.
The firmware now enters the main UI directly after hardware initialization.

Keep startup free of LVGL overlays, transforms and delays so boot remains deterministic and memory-light.
