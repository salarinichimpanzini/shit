# Compilation guard

Before opening Arduino IDE, run:

```text
tools\preflight.bat
```

This is designed to catch the recurring LVGL error class where the target object is accidentally omitted from a call. The guard checks the full project source tree for these LVGL 8.x signatures:

```cpp
lv_obj_set_size(obj, width, height);
lv_obj_set_pos(obj, x, y);
lv_obj_set_style_pad_all(obj, padding, selector);
lv_obj_add_event_cb(obj, callback, filter, user_data);
lv_obj_align(obj, align, x_offset, y_offset);
```

The project also contains a single `styleInput(lv_obj_t*)` helper in `ui.cpp`, so text fields do not depend on an undefined helper copied from documentation.
