# Rotation + touch

The ST7796 uses hardware MADCTL rotation while LVGL resolution follows the rotated orientation.
The draw buffer is sized for the maximum physical width (480 x 4 lines) so landscape flushes stay below the shared SPI2 DMA limit.

Touch mapping is derived from the stored rotation and the current LVGL width/height. Do not hard-code 320x480 in UI widgets.

When adding a new page:
- use `display.width()` and `display.height()`;
- put content in `content_` only;
- do not create a second scrollable page container;
- keep the fixed header/back button outside the scrolling area.
