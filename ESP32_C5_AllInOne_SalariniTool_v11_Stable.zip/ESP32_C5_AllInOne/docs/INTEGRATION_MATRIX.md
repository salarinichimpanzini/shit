# Integration matrix

| Supplied example | Integrated module | Result |
|---|---|---|
| `01_exio` | `board_io.*` + `config.h` | The shared I2C device is supported, but the 16-bit CH32V006 profile is not enabled in the live LCD/touch firmware because it conflicts with the 8-bit LCD BSP profile at the same address. |
| `02_I2C_qmi8658` | `sensor_imu.*` | Polling acceleration, gyro and IMU temperature through SensorLib. The supplied legacy demo used a FreeRTOS task; the integrated firmware uses one cooperative scheduler so LVGL/touch/storage stay responsive. |
| `03_SD_Card` | `sd_storage.*` | Shared SPI2 SDSPI mount, card capacity, filesystem access, write/append helpers and CSV logging. |
| `04_I2C_pcf85063` | `sensor_rtc.*` | PCF85063 read/update and serial date/time setting without overwriting the RTC on every boot. |
| `05_shtc3` | `sensor_shtc3.*` | Wake, measure, CRC validation, temperature/humidity conversion and sleep. |
| `06_axp2101_example` | `power_pmu.*` | AXP2101 measurements, charging state, temperature, IRQ events and the example's board-safe charger settings. Serial `status` prints the DCDC/LDO rail state as in the source example. |
| `07_lvgl_demo` | `display.*`, `touch_ft6336.*`, `ui.*`, `board_io.*` | ST7796 initialization, LVGL v8 display flush, FT6336 touch and backlight/board reset handling. |

## Runtime flow

```text
setup()
  |
  |
  +--> common Wire bus on SDA27/SCL26
  |      |
  |      +--> CH32 board IO / reset & power
  |      +--> FT6336 touch
  |      +--> SHTC3
  |      +--> PCF85063
  |      +--> QMI8658
  |      +--> AXP2101
  |
  +--> SPI2 bus init
  |      |
  |      +--> SD/TF mount first, with LCD CS high
  |      +--> ST7796 LCD device/panel init
  |
  +--> LVGL UI
       |

loop()
  |
  +--> cooperative sensor/RTC/PMU/IO scheduler
  +--> SD CSV logging
  +--> LVGL tick + event handling
  +--> non-blocking serial command polling
```
