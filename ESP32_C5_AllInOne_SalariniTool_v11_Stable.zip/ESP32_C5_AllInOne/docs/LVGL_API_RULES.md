# SALARINI TOOL — LVGL API rules

Use the LVGL 8.x signatures exactly. The object is always the first argument for object style/geometry calls.

```cpp
lv_obj_set_size(obj, width, height);
lv_obj_set_pos(obj, x, y);
lv_obj_set_style_pad_all(obj, padding, selector);
lv_obj_add_event_cb(obj, callback, LV_EVENT_CLICKED, user_data);
lv_obj_align(obj, align, x_offset, y_offset);
```

Never write `lv_obj_set_style_pad_all(5, 0)`, `lv_obj_set_size(width, height)`, or `lv_obj_set_pos(x, y)`: the first form is missing the target object, and the latter two are missing both the target object and one coordinate/dimension.

## Input fields

`ui.cpp` owns the shared `styleInput(lv_obj_t*)` helper. Reuse `makeField(...)` for normal text fields instead of inventing a new style.

## Pre-flight check

Run `tools\check_lvgl_api.bat` before compiling. It checks the common signatures that caused the historical build failures in this firmware.
