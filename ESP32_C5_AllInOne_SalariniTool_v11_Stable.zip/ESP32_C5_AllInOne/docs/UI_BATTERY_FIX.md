# UI + battery fix

## Layout rules
- `content_` is the only vertical scroll surface.
- Child panels/lists are non-scrollable unless there is a specific reason.
- `makeLabel()` assigns a bounded width and clips single-line labels; multiline labels wrap.
- Keep at least 6 px between controls and 10 px page margins.
- Two-column controls use 145 px cards with a 10 px gap on the 320 px portrait display.

## Battery percentage
The UI percentage is derived from the measured AXP2101 battery voltage using a configurable single-cell Li-ion lookup curve from 3.30 V (0%) to 4.20 V (100%). The PMU percentage register is intentionally not displayed as the primary value because it can be stuck at a rail value on some board revisions.

This is an estimate from voltage, not a coulomb-counter fuel-gauge reading. For a different battery chemistry, adjust `voltageToPercent()` in `power_pmu.cpp`.
