# SALARINI TOOL — 2026-10 UI rebuild

## Fixed
- Removed LVGL `transform_zoom` based startup animation that was requesting transparent drawing layers.
- Kept `LV_COLOR_SCREEN_TRANSP=0` to avoid unnecessary layer memory use.
- Disabled LVGL theme grow/shadow features not needed by the interface.
- Replaced the handwritten PCF85063 access with the current `SensorPCF85063` driver from SensorLib.

## UI
- Rebuilt the main screen as a cyber/security field dashboard rather than a terminal.
- Added fixed header/footer and separated content grid.
- Added internal scrollable module lists.
- Added large phone-like software keyboard with ABC/123/SYMBOLS modes, shift, space, backspace and OK.
- Text fields explicitly open the keyboard on touch/click/focus.
- Added DNS resolver and expanded passive/local diagnostics pages.

## Startup
- Added opaque-part skull animation: approach, jaw movement, scanlines, status-phase animation and SALARINI/TOOL logo inside the mouth.

## Security posture
- Menu modules remain passive/local/user-authorized.
- Packet interference, deauthentication, jamming and credential-capture workflows are not included.

## SALARINI TOOL — WiFi/Settings pass

- Added separate WIFI SCAN, WIFI ANALYZER, SELECT WIFI and WIFI ATTACKS (passive-only) pages.
- Added channel/RSSI/open-AP inventory and scan animation.
- Added persistent orientation controls: 0°, 90°, 180°, 270°.
- Added SETTINGS environment/hardware view.
- Added SALARINI FIRMWARE identity/credit page and RF/nRF24 future skeletons.
- Fixed the repeated LVGL screen-layer warning by shipping the project `lv_conf.h` inside the bundled LVGL library.
- Fixed `lv_obj_set_size`/`lv_obj_set_pos` call signatures in the diagnostic console.
- Removed the deprecated PCF85063 wrapper from the firmware source; RTC access is implemented directly over I2C.
- Fixed the soft keyboard numeric/symbol backspace placement.
## 2026-10-03 — buildSettings compile fix
- Fixed temporary `String` being passed to `makeLabel()` without keeping a valid `const char*` for the call.
- Fixed `orientationEvent` registration to pass `LV_EVENT_CLICKED` as the event filter and the orientation index as user data.
