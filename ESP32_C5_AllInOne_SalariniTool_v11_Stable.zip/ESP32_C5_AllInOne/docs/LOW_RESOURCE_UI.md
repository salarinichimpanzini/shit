# SALARINI TOOL v9 — low-resource UI

The UI deliberately avoids charts, shadows, image widgets, transparent screen layers, nested scroll containers and transform animations.

## Menu tree

```text
SALARINI TOOL
|
|-- Exploit
|   |-- Deauth
|   |   |-- APs
|   |   |   |-- All APs
|   |   |   |-- Channel
|   |   |   `-- Select Wifi
|   |   |-- STAs
|   |   |   `-- Select Station
|   |   |-- Evil Twin
|   |   |   `-- Select Wifi
|   |   |-- cool stuff
|   |   |   |-- deauth air play
|   |   |   |-- game1
|   |   |   `-- game2
|   |   |-- Beacon
|   |   |   |-- All SSIDs Dupe
|   |   |   |-- Selected Wifi Dupe
|   |   |   |-- Random
|   |   |   |-- Channel
|   |   |   `-- Prefix
|   |   |-- AP Spoofing
|   |   |   `-- Selected
|   |   `-- B. T Adv
|   |       |-- Samsung
|   |       `-- iOS
|   |-- Scan
|   |-- Packet Monitor
|   |-- Settings
|   `-- About
```

The exploit-named entries are navigation/placeholder slots only. This firmware implements passive Wi-Fi survey and connection features; it does not add deauthentication, jamming, injection, credential capture or other disruptive attack routines.

## Performance rules

- Keep one vertically scrolling `content_` container.
- Use fixed-height rows (34–42 px) and `LV_PCT(100)` width.
- Avoid shadows, gradients, opacity stacks and transform/zoom animations.
- Avoid nested scrolling widgets.
- Use at most one lightweight LVGL timer for small UI indicators.
- Refresh sensors around 700 ms and screen data around 350 ms; slow down further for expensive modules.
- Keep the display refresh loop around 60 FPS (`16 ms`) rather than calling `lv_timer_handler()` every 5 ms.
- Prefer a single text block over many decorative widgets.

## Adding a menu entry

Add one `makeRow("label", "hint", VIEW_..., accent, kind);` call inside the appropriate `build...()` function. Add a new `View` enum item and one build method only when the target page needs its own screen.

## Adding a future module

Implement the hardware/logic in a separate `.cpp/.h` pair. The UI callback should only start the operation or update a status string. Do not put polling loops or delays inside an LVGL callback.


## v11.1
- Wi-Fi scan rows use one label per AP instead of two.
- LVGL handler target is 50 FPS.
- Page transitions avoid whole-tree opacity/layer animation.
